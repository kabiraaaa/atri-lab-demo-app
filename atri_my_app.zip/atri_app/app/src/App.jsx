import { Routes, Route } from "react-router-dom";
import "./styles.css";
import HomePage from "./pages/HomePage.jsx";
import Home from "./pages/Home.jsx";

export default function App() {
  return (
    <Routes>
      <Route path="/HomePage" element={<HomePage />} />
<Route path="/" element={<Home />} />
    </Routes>
  );
}
