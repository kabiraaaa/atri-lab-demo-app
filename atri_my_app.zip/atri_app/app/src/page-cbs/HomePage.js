import { useCallback } from "react";
import { callbackFactory } from "../utils/callbackFactory";
export function useFlex9Cb() {
	const onClick = useCallback(callbackFactory("Flex9", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage4Cb() {
	const onClick = useCallback(callbackFactory("Image4", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex10Cb() {
	const onClick = useCallback(callbackFactory("Flex10", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox5Cb() {
	const onClick = useCallback(callbackFactory("TextBox5", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox6Cb() {
	const onClick = useCallback(callbackFactory("TextBox6", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox7Cb() {
	const onClick = useCallback(callbackFactory("TextBox7", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox8Cb() {
	const onClick = useCallback(callbackFactory("TextBox8", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage5Cb() {
	const onClick = useCallback(callbackFactory("Image5", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage6Cb() {
	const onClick = useCallback(callbackFactory("Image6", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useDiv8Cb() {
	const onClick = useCallback(callbackFactory("Div8", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox9Cb() {
	const onClick = useCallback(callbackFactory("TextBox9", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useDiv9Cb() {
	const onClick = useCallback(callbackFactory("Div9", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex11Cb() {
	const onClick = useCallback(callbackFactory("Flex11", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox11Cb() {
	const onClick = useCallback(callbackFactory("TextBox11", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox12Cb() {
	const onClick = useCallback(callbackFactory("TextBox12", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useDiv10Cb() {
	const onClick = useCallback(callbackFactory("Div10", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex12Cb() {
	const onClick = useCallback(callbackFactory("Flex12", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox15Cb() {
	const onClick = useCallback(callbackFactory("TextBox15", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useDiv11Cb() {
	const onClick = useCallback(callbackFactory("Div11", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox17Cb() {
	const onClick = useCallback(callbackFactory("TextBox17", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useDiv12Cb() {
	const onClick = useCallback(callbackFactory("Div12", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox18Cb() {
	const onClick = useCallback(callbackFactory("TextBox18", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useDiv13Cb() {
	const onClick = useCallback(callbackFactory("Div13", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox19Cb() {
	const onClick = useCallback(callbackFactory("TextBox19", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useDiv14Cb() {
	const onClick = useCallback(callbackFactory("Div14", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox22Cb() {
	const onClick = useCallback(callbackFactory("TextBox22", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useDiv15Cb() {
	const onClick = useCallback(callbackFactory("Div15", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox24Cb() {
	const onClick = useCallback(callbackFactory("TextBox24", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useDiv16Cb() {
	const onClick = useCallback(callbackFactory("Div16", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex13Cb() {
	const onClick = useCallback(callbackFactory("Flex13", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage9Cb() {
	const onClick = useCallback(callbackFactory("Image9", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex14Cb() {
	const onClick = useCallback(callbackFactory("Flex14", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox28Cb() {
	const onClick = useCallback(callbackFactory("TextBox28", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox29Cb() {
	const onClick = useCallback(callbackFactory("TextBox29", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex15Cb() {
	const onClick = useCallback(callbackFactory("Flex15", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox30Cb() {
	const onClick = useCallback(callbackFactory("TextBox30", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox31Cb() {
	const onClick = useCallback(callbackFactory("TextBox31", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox32Cb() {
	const onClick = useCallback(callbackFactory("TextBox32", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox33Cb() {
	const onClick = useCallback(callbackFactory("TextBox33", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox34Cb() {
	const onClick = useCallback(callbackFactory("TextBox34", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox35Cb() {
	const onClick = useCallback(callbackFactory("TextBox35", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox36Cb() {
	const onClick = useCallback(callbackFactory("TextBox36", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox37Cb() {
	const onClick = useCallback(callbackFactory("TextBox37", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex16Cb() {
	const onClick = useCallback(callbackFactory("Flex16", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox38Cb() {
	const onClick = useCallback(callbackFactory("TextBox38", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox39Cb() {
	const onClick = useCallback(callbackFactory("TextBox39", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex17Cb() {
	const onClick = useCallback(callbackFactory("Flex17", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage10Cb() {
	const onClick = useCallback(callbackFactory("Image10", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex18Cb() {
	const onClick = useCallback(callbackFactory("Flex18", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox40Cb() {
	const onClick = useCallback(callbackFactory("TextBox40", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox41Cb() {
	const onClick = useCallback(callbackFactory("TextBox41", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox42Cb() {
	const onClick = useCallback(callbackFactory("TextBox42", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox43Cb() {
	const onClick = useCallback(callbackFactory("TextBox43", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox44Cb() {
	const onClick = useCallback(callbackFactory("TextBox44", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex19Cb() {
	const onClick = useCallback(callbackFactory("Flex19", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox45Cb() {
	const onClick = useCallback(callbackFactory("TextBox45", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage11Cb() {
	const onClick = useCallback(callbackFactory("Image11", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex20Cb() {
	const onClick = useCallback(callbackFactory("Flex20", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex21Cb() {
	const onClick = useCallback(callbackFactory("Flex21", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox46Cb() {
	const onClick = useCallback(callbackFactory("TextBox46", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox47Cb() {
	const onClick = useCallback(callbackFactory("TextBox47", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox48Cb() {
	const onClick = useCallback(callbackFactory("TextBox48", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox49Cb() {
	const onClick = useCallback(callbackFactory("TextBox49", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex22Cb() {
	const onClick = useCallback(callbackFactory("Flex22", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox50Cb() {
	const onClick = useCallback(callbackFactory("TextBox50", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox51Cb() {
	const onClick = useCallback(callbackFactory("TextBox51", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex23Cb() {
	const onClick = useCallback(callbackFactory("Flex23", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage13Cb() {
	const onClick = useCallback(callbackFactory("Image13", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex24Cb() {
	const onClick = useCallback(callbackFactory("Flex24", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex25Cb() {
	const onClick = useCallback(callbackFactory("Flex25", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useDiv18Cb() {
	const onClick = useCallback(callbackFactory("Div18", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox53Cb() {
	const onClick = useCallback(callbackFactory("TextBox53", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox55Cb() {
	const onClick = useCallback(callbackFactory("TextBox55", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox58Cb() {
	const onClick = useCallback(callbackFactory("TextBox58", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex26Cb() {
	const onClick = useCallback(callbackFactory("Flex26", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox59Cb() {
	const onClick = useCallback(callbackFactory("TextBox59", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage16Cb() {
	const onClick = useCallback(callbackFactory("Image16", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex27Cb() {
	const onClick = useCallback(callbackFactory("Flex27", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex28Cb() {
	const onClick = useCallback(callbackFactory("Flex28", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox60Cb() {
	const onClick = useCallback(callbackFactory("TextBox60", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useDiv19Cb() {
	const onClick = useCallback(callbackFactory("Div19", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex29Cb() {
	const onClick = useCallback(callbackFactory("Flex29", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox61Cb() {
	const onClick = useCallback(callbackFactory("TextBox61", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox62Cb() {
	const onClick = useCallback(callbackFactory("TextBox62", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useDiv20Cb() {
	const onClick = useCallback(callbackFactory("Div20", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex30Cb() {
	const onClick = useCallback(callbackFactory("Flex30", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex31Cb() {
	const onClick = useCallback(callbackFactory("Flex31", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage17Cb() {
	const onClick = useCallback(callbackFactory("Image17", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex32Cb() {
	const onClick = useCallback(callbackFactory("Flex32", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex33Cb() {
	const onClick = useCallback(callbackFactory("Flex33", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox63Cb() {
	const onClick = useCallback(callbackFactory("TextBox63", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox64Cb() {
	const onClick = useCallback(callbackFactory("TextBox64", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage20Cb() {
	const onClick = useCallback(callbackFactory("Image20", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox67Cb() {
	const onClick = useCallback(callbackFactory("TextBox67", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage21Cb() {
	const onClick = useCallback(callbackFactory("Image21", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox77Cb() {
	const onClick = useCallback(callbackFactory("TextBox77", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox78Cb() {
	const onClick = useCallback(callbackFactory("TextBox78", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox79Cb() {
	const onClick = useCallback(callbackFactory("TextBox79", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox80Cb() {
	const onClick = useCallback(callbackFactory("TextBox80", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox81Cb() {
	const onClick = useCallback(callbackFactory("TextBox81", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox82Cb() {
	const onClick = useCallback(callbackFactory("TextBox82", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox83Cb() {
	const onClick = useCallback(callbackFactory("TextBox83", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox84Cb() {
	const onClick = useCallback(callbackFactory("TextBox84", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox85Cb() {
	const onClick = useCallback(callbackFactory("TextBox85", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox88Cb() {
	const onClick = useCallback(callbackFactory("TextBox88", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox102Cb() {
	const onClick = useCallback(callbackFactory("TextBox102", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox103Cb() {
	const onClick = useCallback(callbackFactory("TextBox103", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox104Cb() {
	const onClick = useCallback(callbackFactory("TextBox104", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox105Cb() {
	const onClick = useCallback(callbackFactory("TextBox105", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox106Cb() {
	const onClick = useCallback(callbackFactory("TextBox106", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage25Cb() {
	const onClick = useCallback(callbackFactory("Image25", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox107Cb() {
	const onClick = useCallback(callbackFactory("TextBox107", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox108Cb() {
	const onClick = useCallback(callbackFactory("TextBox108", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox109Cb() {
	const onClick = useCallback(callbackFactory("TextBox109", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox110Cb() {
	const onClick = useCallback(callbackFactory("TextBox110", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage26Cb() {
	const onClick = useCallback(callbackFactory("Image26", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox111Cb() {
	const onClick = useCallback(callbackFactory("TextBox111", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox112Cb() {
	const onClick = useCallback(callbackFactory("TextBox112", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox113Cb() {
	const onClick = useCallback(callbackFactory("TextBox113", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox114Cb() {
	const onClick = useCallback(callbackFactory("TextBox114", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage27Cb() {
	const onClick = useCallback(callbackFactory("Image27", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex38Cb() {
	const onClick = useCallback(callbackFactory("Flex38", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex39Cb() {
	const onClick = useCallback(callbackFactory("Flex39", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex40Cb() {
	const onClick = useCallback(callbackFactory("Flex40", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex41Cb() {
	const onClick = useCallback(callbackFactory("Flex41", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useDiv22Cb() {
	const onClick = useCallback(callbackFactory("Div22", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox115Cb() {
	const onClick = useCallback(callbackFactory("TextBox115", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox116Cb() {
	const onClick = useCallback(callbackFactory("TextBox116", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox117Cb() {
	const onClick = useCallback(callbackFactory("TextBox117", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex42Cb() {
	const onClick = useCallback(callbackFactory("Flex42", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex43Cb() {
	const onClick = useCallback(callbackFactory("Flex43", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox120Cb() {
	const onClick = useCallback(callbackFactory("TextBox120", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex44Cb() {
	const onClick = useCallback(callbackFactory("Flex44", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage28Cb() {
	const onClick = useCallback(callbackFactory("Image28", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex45Cb() {
	const onClick = useCallback(callbackFactory("Flex45", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox121Cb() {
	const onClick = useCallback(callbackFactory("TextBox121", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex46Cb() {
	const onClick = useCallback(callbackFactory("Flex46", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex47Cb() {
	const onClick = useCallback(callbackFactory("Flex47", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage29Cb() {
	const onClick = useCallback(callbackFactory("Image29", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex48Cb() {
	const onClick = useCallback(callbackFactory("Flex48", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox125Cb() {
	const onClick = useCallback(callbackFactory("TextBox125", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox126Cb() {
	const onClick = useCallback(callbackFactory("TextBox126", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox127Cb() {
	const onClick = useCallback(callbackFactory("TextBox127", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox128Cb() {
	const onClick = useCallback(callbackFactory("TextBox128", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex49Cb() {
	const onClick = useCallback(callbackFactory("Flex49", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox129Cb() {
	const onClick = useCallback(callbackFactory("TextBox129", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox130Cb() {
	const onClick = useCallback(callbackFactory("TextBox130", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox131Cb() {
	const onClick = useCallback(callbackFactory("TextBox131", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex50Cb() {
	const onClick = useCallback(callbackFactory("Flex50", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex51Cb() {
	const onClick = useCallback(callbackFactory("Flex51", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox132Cb() {
	const onClick = useCallback(callbackFactory("TextBox132", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useDiv24Cb() {
	const onClick = useCallback(callbackFactory("Div24", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex52Cb() {
	const onClick = useCallback(callbackFactory("Flex52", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex53Cb() {
	const onClick = useCallback(callbackFactory("Flex53", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox133Cb() {
	const onClick = useCallback(callbackFactory("TextBox133", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox134Cb() {
	const onClick = useCallback(callbackFactory("TextBox134", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox136Cb() {
	const onClick = useCallback(callbackFactory("TextBox136", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage30Cb() {
	const onClick = useCallback(callbackFactory("Image30", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox138Cb() {
	const onClick = useCallback(callbackFactory("TextBox138", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useDiv25Cb() {
	const onClick = useCallback(callbackFactory("Div25", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex54Cb() {
	const onClick = useCallback(callbackFactory("Flex54", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex55Cb() {
	const onClick = useCallback(callbackFactory("Flex55", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage31Cb() {
	const onClick = useCallback(callbackFactory("Image31", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex57Cb() {
	const onClick = useCallback(callbackFactory("Flex57", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex59Cb() {
	const onClick = useCallback(callbackFactory("Flex59", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox140Cb() {
	const onClick = useCallback(callbackFactory("TextBox140", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox141Cb() {
	const onClick = useCallback(callbackFactory("TextBox141", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox142Cb() {
	const onClick = useCallback(callbackFactory("TextBox142", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox143Cb() {
	const onClick = useCallback(callbackFactory("TextBox143", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox144Cb() {
	const onClick = useCallback(callbackFactory("TextBox144", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox145Cb() {
	const onClick = useCallback(callbackFactory("TextBox145", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox155Cb() {
	const onClick = useCallback(callbackFactory("TextBox155", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex62Cb() {
	const onClick = useCallback(callbackFactory("Flex62", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex67Cb() {
	const onClick = useCallback(callbackFactory("Flex67", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox169Cb() {
	const onClick = useCallback(callbackFactory("TextBox169", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox170Cb() {
	const onClick = useCallback(callbackFactory("TextBox170", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox171Cb() {
	const onClick = useCallback(callbackFactory("TextBox171", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox172Cb() {
	const onClick = useCallback(callbackFactory("TextBox172", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox173Cb() {
	const onClick = useCallback(callbackFactory("TextBox173", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox204Cb() {
	const onClick = useCallback(callbackFactory("TextBox204", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox205Cb() {
	const onClick = useCallback(callbackFactory("TextBox205", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox206Cb() {
	const onClick = useCallback(callbackFactory("TextBox206", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox207Cb() {
	const onClick = useCallback(callbackFactory("TextBox207", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox208Cb() {
	const onClick = useCallback(callbackFactory("TextBox208", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox209Cb() {
	const onClick = useCallback(callbackFactory("TextBox209", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex73Cb() {
	const onClick = useCallback(callbackFactory("Flex73", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox211Cb() {
	const onClick = useCallback(callbackFactory("TextBox211", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox212Cb() {
	const onClick = useCallback(callbackFactory("TextBox212", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox213Cb() {
	const onClick = useCallback(callbackFactory("TextBox213", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox214Cb() {
	const onClick = useCallback(callbackFactory("TextBox214", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox215Cb() {
	const onClick = useCallback(callbackFactory("TextBox215", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex74Cb() {
	const onClick = useCallback(callbackFactory("Flex74", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox227Cb() {
	const onClick = useCallback(callbackFactory("TextBox227", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox228Cb() {
	const onClick = useCallback(callbackFactory("TextBox228", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox229Cb() {
	const onClick = useCallback(callbackFactory("TextBox229", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox230Cb() {
	const onClick = useCallback(callbackFactory("TextBox230", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox231Cb() {
	const onClick = useCallback(callbackFactory("TextBox231", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox232Cb() {
	const onClick = useCallback(callbackFactory("TextBox232", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex77Cb() {
	const onClick = useCallback(callbackFactory("Flex77", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex78Cb() {
	const onClick = useCallback(callbackFactory("Flex78", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox233Cb() {
	const onClick = useCallback(callbackFactory("TextBox233", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex79Cb() {
	const onClick = useCallback(callbackFactory("Flex79", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox234Cb() {
	const onClick = useCallback(callbackFactory("TextBox234", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox235Cb() {
	const onClick = useCallback(callbackFactory("TextBox235", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useDiv26Cb() {
	const onClick = useCallback(callbackFactory("Div26", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useFlex80Cb() {
	const onClick = useCallback(callbackFactory("Flex80", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useTextBox236Cb() {
	const onClick = useCallback(callbackFactory("TextBox236", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}
export function useImage34Cb() {
	const onClick = useCallback(callbackFactory("Image34", "HomePage", "/HomePage", "onClick", 
			{
  "handlers": [
    {
      "sendEventData": true
    }
  ],
  "actions": [
    {
      "type": "do_nothing"
    }
  ]
}), [])
	return { onClick }
}