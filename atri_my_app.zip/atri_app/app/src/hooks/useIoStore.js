import create from "zustand";

const useIoStore = create((set) => {
  return {
  "HomePage": {},
  "Home": {}
}});

export default useIoStore;
